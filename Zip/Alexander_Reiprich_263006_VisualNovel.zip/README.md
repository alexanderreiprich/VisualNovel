# Visual Novel - Endabgabe

Abgegeben von: Alexander Reiprich

Modul: Visual Novel

Semester: SoSe22

---

Link zur Visual Novel: https://alexanderreiprich.github.io/VisualNovel/

Link zum Source Ordner: https://github.com/alexanderreiprich/VisualNovel/tree/main/Source

Link zum Konzeptdokument: https://github.com/alexanderreiprich/VisualNovel/blob/main/Concept/concept.pdf

Link zum Zipfile: https://github.com/alexanderreiprich/VisualNovel/blob/main/Zip/Alexander_Reiprich_263006_VisualNovel.zip
