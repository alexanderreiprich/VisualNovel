namespace Endabgabe {
  export async function Empty(): ƒS.SceneReturn {
    // stop snooping around >:(
  }
}